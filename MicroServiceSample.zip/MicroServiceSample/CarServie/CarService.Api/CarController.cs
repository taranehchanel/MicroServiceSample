﻿using CarService.Domain;
using CarService.Service;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;

namespace CarService.Api;

[Route("/api/v1/cars")]
public class CarController(CarRepository repository)
{
    [HttpPost]
    public async Task AddCar([FromBody] CarRepository.CarDto car)
    {
        await repository.Add(car);
    }

    [HttpGet]
    public async Task<IEnumerable<Car>> GetAll()
    {
        return await repository.GetAll();
    }
}