﻿using System.ComponentModel.DataAnnotations;
using PersonService.Domain;
using PersonService.Persistence;
using Microsoft.EntityFrameworkCore;

namespace PersonService.Service;

public class PersonRepository(PersonDbContext dbContext)
{
    public async Task<IEnumerable<Person>> GetAll()
    {
        return await dbContext.Persons.ToListAsync();
    }

    public async Task Add(PersonDto person)
    {
        dbContext.Persons.Add(new Person{FirstName = person.FirstName, LastName = person.LastName}); //test to do
        await dbContext.SaveChangesAsync();
    }
}

public class PersonDto
{
    [Required]
    public string FirstName { get; set; }
    [Required]
    public string LastName { get; set; }
}