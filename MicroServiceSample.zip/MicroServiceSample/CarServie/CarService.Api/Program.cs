using CarService.Domain;
using CarService.Persistence;
using CarService.Service;
using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers();
builder.Services.AddSingleton<IMongoClient>(new MongoClient(builder.Configuration.GetConnectionString("Mongo")));
builder.Services.AddDbContext<CarDbContext>((s, c)
    => c.UseMongoDB(s.GetRequiredService<IMongoClient>(), databaseName: "cars"));
builder.Services.AddScoped<CarRepository>();
builder.Services.AddHttpClient("persons_client", c => c.BaseAddress = new Uri("http://localhost:5129"));

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    await scope.ServiceProvider.GetRequiredService<CarDbContext>().Database.EnsureCreatedAsync();
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();
app.Run();
