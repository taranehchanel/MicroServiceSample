﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace PersonService.Domain;

public class Person
{
    [BsonId]
    [BsonRepresentation(BsonType.String)]
    public string Id { get; set; }= ObjectId.GenerateNewId().ToString();

    
    [Required]
    public string FirstName { get; set; }
    [Required]
    public string LastName { get; set; }
}