using PersonService.Domain;
using PersonService.Persistence;
using PersonService.Service;
using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers();
builder.Services.AddSingleton<IMongoClient>(new MongoClient(builder.Configuration.GetConnectionString("Mongo")));
builder.Services.AddDbContext<PersonDbContext>((s, c)
    => c.UseMongoDB(s.GetRequiredService<IMongoClient>(), databaseName: "persons"));
builder.Services.AddScoped<PersonRepository>();
builder.Services.AddHttpClient("cars_client", c => c.BaseAddress = new Uri("http://localhost:5139"));

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    await scope.ServiceProvider.GetRequiredService<PersonDbContext>().Database.EnsureCreatedAsync();
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();
app.Run();
