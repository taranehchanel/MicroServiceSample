﻿using PersonService.Domain;
using PersonService.Service;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;

namespace PersonService.Api;

[Route("/api/v1/persons")]
public class PersonController(PersonRepository repository)
{
    [HttpPost]
    public async Task AddPerson([FromBody] PersonDto person)
    {
        await repository.Add(person);
    }

    [HttpGet]
    public async Task<IEnumerable<Person>> GetAll()
    {
        return await repository.GetAll();
    }
}