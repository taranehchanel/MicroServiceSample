﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CarService.Domain;

public class Car
{
    [BsonId]
    [BsonRepresentation(BsonType.String)]
    public string Id { get; set; }= ObjectId.GenerateNewId().ToString();

    
    [Required]
    public string Model { get; set; }
    [Required]
    public string Name { get; set; }
    [Required]
    public DateTime ManufacturingDate { get; set; }
}