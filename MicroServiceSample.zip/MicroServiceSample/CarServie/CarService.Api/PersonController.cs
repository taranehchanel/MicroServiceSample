﻿using Microsoft.AspNetCore.Mvc;

namespace CarService.Api;

[Route("/api/v1/persons")]
public class PersonController(IHttpClientFactory factory)
{
    
    [HttpGet]
    public async Task<List<PersonDto>?> GetAll()
    {
        var httpClient = factory.CreateClient("persons_client");
        return await httpClient.GetFromJsonAsync<List<PersonDto>>("/api/v1/persons");
    }
}

public class PersonDto
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    
}