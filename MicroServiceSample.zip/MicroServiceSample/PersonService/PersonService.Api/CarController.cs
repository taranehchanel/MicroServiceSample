﻿using Microsoft.AspNetCore.Mvc;
namespace PersonService.Api;

[Route("/api/v1/cars")]
public class CarController(IHttpClientFactory factory)
{
    [HttpGet]
    public async Task<List<CarDto>?> GetAll()
    {
        var httpClient = factory.CreateClient("cars_client");
        return await httpClient.GetFromJsonAsync<List<CarDto>>("/api/v1/cars");
    }
}

public class CarDto
{
    public string Model { get; set; }
    public string Name { get; set; }
    public DateTime ManufacturingDate { get; set; }
}