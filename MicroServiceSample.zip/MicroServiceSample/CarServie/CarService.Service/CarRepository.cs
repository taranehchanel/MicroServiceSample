﻿using System.ComponentModel.DataAnnotations;
using CarService.Domain;
using CarService.Persistence;
using Microsoft.EntityFrameworkCore;

namespace CarService.Service;

public class CarRepository(CarDbContext dbContext)
{
    public async Task<IEnumerable<Car>> GetAll()
    {
        return await dbContext.Cars.ToListAsync();
    }

    public async Task Add(CarDto car)
    {
        dbContext.Cars.Add(new Car{Name = car.Name,Model = car.Model,ManufacturingDate = DateTime.Now});
        await dbContext.SaveChangesAsync();
    }

    public class CarDto
    {
        [Required]
        public string Model { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public DateTime ManufacturingDate { get; set; }
    }
}
